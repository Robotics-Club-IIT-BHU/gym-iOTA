def Hello():
    print("HELLO")
